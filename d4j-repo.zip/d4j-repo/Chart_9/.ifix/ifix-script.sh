#!/bin/sh
export JAVA_HOME=`/usr/libexec/java_home -v 11.0.16.1`

if [ $# == 3 ];then
cd $1
mvn test -Dtest="$2"\#"$3"
elif [ $# == 4 ];then
cd $1
mvn test -pl "$2" -Dtest="$3"\#"$4"
fi
