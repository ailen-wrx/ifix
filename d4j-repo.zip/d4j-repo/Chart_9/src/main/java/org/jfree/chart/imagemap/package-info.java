/**
 * Classes, including {@code ImageMapUtils}, for creating HTML image maps.
 */
package org.jfree.chart.imagemap;
